--
-- PostgreSQL database dump
--

\restrict lxucySsBfRWwC2NddwXhgXVPhUJJWcwKGxNo1qLaUpAAPlqJJDIzrluZ8xFEFuk

-- Dumped from database version 14.23 (Debian 14.23-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: odoo
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO odoo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    ruc character varying(13) NOT NULL,
    direccion text,
    telefono character varying(20),
    email character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clientes OWNER TO odoo;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO odoo;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: detalle_factura; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.detalle_factura (
    id integer NOT NULL,
    factura_id integer,
    producto_id integer,
    cantidad integer NOT NULL,
    precio_unitario numeric(10,2) NOT NULL,
    total numeric(12,2) NOT NULL
);


ALTER TABLE public.detalle_factura OWNER TO odoo;

--
-- Name: detalle_factura_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.detalle_factura_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.detalle_factura_id_seq OWNER TO odoo;

--
-- Name: detalle_factura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.detalle_factura_id_seq OWNED BY public.detalle_factura.id;


--
-- Name: facturas; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.facturas (
    id integer NOT NULL,
    cliente_id integer,
    numero character varying(20) NOT NULL,
    fecha_emision date DEFAULT CURRENT_DATE NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    iva numeric(12,2) NOT NULL,
    total numeric(12,2) NOT NULL,
    estado character varying(20) DEFAULT 'pendiente'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.facturas OWNER TO odoo;

--
-- Name: facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.facturas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.facturas_id_seq OWNER TO odoo;

--
-- Name: facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.facturas_id_seq OWNED BY public.facturas.id;


--
-- Name: productos; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    codigo character varying(20) NOT NULL,
    nombre character varying(200) NOT NULL,
    descripcion text,
    precio_compra numeric(10,2) NOT NULL,
    precio_venta numeric(10,2) NOT NULL,
    stock_actual integer DEFAULT 0,
    categoria character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.productos OWNER TO odoo;

--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos_id_seq OWNER TO odoo;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: detalle_factura id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.detalle_factura ALTER COLUMN id SET DEFAULT nextval('public.detalle_factura_id_seq'::regclass);


--
-- Name: facturas id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.facturas ALTER COLUMN id SET DEFAULT nextval('public.facturas_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.clientes (id, nombre, ruc, direccion, telefono, email, created_at) FROM stdin;
1	Seguridad Total Cía. Ltda.	1792837465001	Av. Amazonas N35-100, Quito	022345678	info@seguridadtotal.ec	2026-07-18 16:47:19.749518
2	Control de Acceso SA	1793847562001	Calle Elia Liut N52-50, Quito	023456789	admin@controacceso.ec	2026-07-18 16:47:19.749518
3	Vigilancia Proactiva Cía.	1794857364001	Av. Boyacá Oe4-12, Quito	025678901	contacto@vigilanciapro.ec	2026-07-18 16:47:19.749518
4	Cámaras y Sensores SA	1795868273001	Av. 6 de Diciembre N30-80, Quito	027890123	ventas@camarasysensores.ec	2026-07-18 16:47:19.749518
5	Automatización Inteligente	1796879382001	Av. República E7-50, Quito	028901234	soporte@autointeligente.ec	2026-07-18 16:47:19.749518
6	Sistemas de Seguridad Integrados	1797890491001	Calle Ramón Chiriboga Oe3-20, Quito	029012345	gerencia@sisintegrados.ec	2026-07-18 16:47:19.749518
7	Electrodomésticos del Sur	0192837465001	Av. 9 de Octubre 1120, Guayaquil	042345678	info@electrosur.ec	2026-07-18 16:47:19.749518
8	Distribuidora de Tecnología	0293847562001	Calle Panamá 450, Guayaquil	043456789	ventas@distecnologia.ec	2026-07-18 16:47:19.749518
9	Comercializadora Global	0394857461001	Av. Quito 220, Cuenca	072345678	admin@comercialglobal.ec	2026-07-18 16:47:19.749518
10	Importadora Andina	0495868372001	Calle Sucre 5-78, Ambato	032345678	contacto@importadoraandina.ec	2026-07-18 16:47:19.749518
\.


--
-- Data for Name: detalle_factura; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.detalle_factura (id, factura_id, producto_id, cantidad, precio_unitario, total) FROM stdin;
1	1	1	20	145.00	2900.00
2	1	15	10	210.00	2100.00
3	2	4	5	590.00	2950.00
4	2	7	10	160.00	1600.00
\.


--
-- Data for Name: facturas; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.facturas (id, cliente_id, numero, fecha_emision, subtotal, iva, total, estado, created_at) FROM stdin;
1	1	FAC-2026-0001	2026-07-01	4500.00	540.00	5040.00	pagada	2026-07-18 16:47:19.796759
2	2	FAC-2026-0002	2026-07-02	2300.00	276.00	2576.00	pendiente	2026-07-18 16:47:19.796759
3	3	FAC-2026-0003	2026-07-03	1250.00	150.00	1400.00	vencida	2026-07-18 16:47:19.796759
4	4	FAC-2026-0004	2026-07-05	7800.00	936.00	8736.00	pagada	2026-07-18 16:47:19.796759
5	5	FAC-2026-0005	2026-07-07	3200.00	384.00	3584.00	pendiente	2026-07-18 16:47:19.796759
6	6	FAC-2026-0006	2026-07-10	11000.00	1320.00	12320.00	pagada	2026-07-18 16:47:19.796759
7	7	FAC-2026-0007	2026-07-12	670.00	80.40	750.40	pendiente	2026-07-18 16:47:19.796759
8	8	FAC-2026-0008	2026-07-14	5400.00	648.00	6048.00	pagada	2026-07-18 16:47:19.796759
9	9	FAC-2026-0009	2026-07-15	1800.00	216.00	2016.00	pendiente	2026-07-18 16:47:19.796759
10	10	FAC-2026-0010	2026-07-16	9200.00	1104.00	10304.00	pendiente	2026-07-18 16:47:19.796759
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.productos (id, codigo, nombre, descripcion, precio_compra, precio_venta, stock_actual, categoria, created_at) FROM stdin;
1	CAM-DS2CD2	Cámara IP Hikvision DS-2CD2T47G2-L	Cámara domo 4MP, visión nocturna, PoE	85.00	145.00	120	Cámaras	2026-07-18 16:47:19.768679
2	CAM-DS2CD8	Cámara IP Hikvision DS-2CD2386G2-I	Cámara domo 8MP, colorvu, PoE	120.00	210.00	85	Cámaras	2026-07-18 16:47:19.768679
3	CAM-TUR4MP	Cámara IP Dahua Turret 4MP	Cámara bala 4MP, IR, IP67	65.00	110.00	200	Cámaras	2026-07-18 16:47:19.768679
4	NVR-HIK32	NVR Hikvision DS-7632NI	Grabador 32 canales, PoE, 4K	350.00	590.00	45	Grabadores	2026-07-18 16:47:19.768679
5	NVR-DAHUA16	NVR Dahua 16 canales	Grabador 16 canales, ePoE	280.00	470.00	30	Grabadores	2026-07-18 16:47:19.768679
6	DVR-HIK8	DVR Hikvision 8 canales	Grabador 8 canales, HD-TVI	150.00	250.00	60	Grabadores	2026-07-18 16:47:19.768679
7	HDD-4TB	Disco Duro WD Purple 4TB	HDD 4TB, vigilancia, 256MB	95.00	160.00	300	Accesorios	2026-07-18 16:47:19.768679
8	HDD-8TB	Disco Duro WD Purple 8TB	HDD 8TB, vigilancia, 256MB	175.00	290.00	150	Accesorios	2026-07-18 16:47:19.768679
9	POE-8P	Switch PoE 8 puertos	Switch 8 puertos PoE+, 100W	90.00	155.00	100	Redes	2026-07-18 16:47:19.768679
10	POE-24P	Switch PoE 24 puertos	Switch 24 puertos PoE+, 250W	250.00	420.00	55	Redes	2026-07-18 16:47:19.768679
11	FIBRA-1KM	Kit Fibra Óptica 1km	Cable fibra óptica monomodo 1km + conectores	180.00	300.00	40	Redes	2026-07-18 16:47:19.768679
12	ALAR-INT	Panel de alarma interior	Panel alarma inalámbrica, 8 zonas	45.00	85.00	250	Alarmas	2026-07-18 16:47:19.768679
13	ALAR-EXT	Sirena exterior con strobe	Sirena electrónica 110dB con luz estroboscópica	25.00	50.00	400	Alarmas	2026-07-18 16:47:19.768679
14	SENS-MOV	Sensor de movimiento	Sensor PIR, 12m alcance, 90°	12.00	25.00	500	Alarmas	2026-07-18 16:47:19.768679
15	CONT-ACC	Control de acceso biométrico	Lector huella + tarjeta, 1000 usuarios	120.00	210.00	75	Control Acceso	2026-07-18 16:47:19.768679
16	TARJ-PROX	Tarjeta proximidad 125kHz	Tarjeta RFID para control acceso	1.50	4.50	2000	Control Acceso	2026-07-18 16:47:19.768679
17	CERR-ELEC	Cerradora eléctrica	Cerradora electromagnética 600lbs	35.00	68.00	300	Control Acceso	2026-07-18 16:47:19.768679
18	UPS-1KVA	UPS APC 1000VA	UPS 1000VA, 8 tomas, gestión red	180.00	310.00	65	Infraestructura	2026-07-18 16:47:19.768679
19	UPS-2KVA	UPS APC 2000VA	UPS 2000VA, rackeable, doble conversión	350.00	580.00	35	Infraestructura	2026-07-18 16:47:19.768679
20	CABLE-UTP	Cable UTP Cat6 305m	Cobre sólido 24AWG, LSZH	85.00	140.00	180	Redes	2026-07-18 16:47:19.768679
21	CABLE-COAX	Cable coaxial RG59 100m	Cable coaxial con alimentación	40.00	70.00	150	Accesorios	2026-07-18 16:47:19.768679
22	FUENTE-12V	Fuente Poder 12V 10A	Fuente switching 12V DC 10A	18.00	35.00	600	Accesorios	2026-07-18 16:47:19.768679
23	SOPORTE-PAR	Soporte pared metálico	Soporte acero inoxidable para cámara	8.00	18.00	800	Accesorios	2026-07-18 16:47:19.768679
24	KIT-TOOLS	Kit herramientas instalación	Crimpeadora, pelacable, probador, conectores	35.00	65.00	100	Accesorios	2026-07-18 16:47:19.768679
25	LEC-HUELLA	Lector biométrico huella	Lector independiente IP65, 5000 usuarios	95.00	170.00	90	Control Acceso	2026-07-18 16:47:19.768679
26	CAB-VIDEO	Cable video balun 100m	Cable UTP + balunes video para CCTV	30.00	55.00	250	Accesorios	2026-07-18 16:47:19.768679
27	ANT-ALARM	Antena alarma GSM	Antena 4G para panel de alarma	15.00	30.00	350	Alarmas	2026-07-18 16:47:19.768679
28	JOY-CAM	Joystick control cámaras PTZ	Joystick para control de cámaras PTZ	120.00	220.00	25	Control Acceso	2026-07-18 16:47:19.768679
29	MONI-22	Monitor 22 pulgadas CCTV	Monitor LED 22" HDMI/VGA	140.00	240.00	40	Accesorios	2026-07-18 16:47:19.768679
30	CAJA-EMPOT	Caja empotrar pared	Caja metálica para instalación empotrada	4.00	10.00	1000	Accesorios	2026-07-18 16:47:19.768679
\.


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.clientes_id_seq', 10, true);


--
-- Name: detalle_factura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.detalle_factura_id_seq', 4, true);


--
-- Name: facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.facturas_id_seq', 10, true);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.productos_id_seq', 30, true);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_ruc_key; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_ruc_key UNIQUE (ruc);


--
-- Name: detalle_factura detalle_factura_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.detalle_factura
    ADD CONSTRAINT detalle_factura_pkey PRIMARY KEY (id);


--
-- Name: facturas facturas_numero_key; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_numero_key UNIQUE (numero);


--
-- Name: facturas facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_pkey PRIMARY KEY (id);


--
-- Name: productos productos_codigo_key; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_codigo_key UNIQUE (codigo);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: detalle_factura detalle_factura_factura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.detalle_factura
    ADD CONSTRAINT detalle_factura_factura_id_fkey FOREIGN KEY (factura_id) REFERENCES public.facturas(id);


--
-- Name: detalle_factura detalle_factura_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.detalle_factura
    ADD CONSTRAINT detalle_factura_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id);


--
-- Name: facturas facturas_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.facturas
    ADD CONSTRAINT facturas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: odoo
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict lxucySsBfRWwC2NddwXhgXVPhUJJWcwKGxNo1qLaUpAAPlqJJDIzrluZ8xFEFuk

