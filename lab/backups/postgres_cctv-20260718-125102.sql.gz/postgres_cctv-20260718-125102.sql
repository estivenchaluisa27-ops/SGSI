--
-- PostgreSQL database dump
--

\restrict 0sHMseLwzs6EoCxtjgSNS76AGHs6tCNVPVys4VInKNPbo1jmN203be7ND8ZCmvr

-- Dumped from database version 14.23 (Debian 14.23-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: odoo
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO odoo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cameras; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.cameras (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    ubicacion character varying(200),
    ip_address character varying(15) NOT NULL,
    puerto integer DEFAULT 554,
    usuario character varying(50),
    contrasena character varying(100),
    modelo character varying(100),
    firmware character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.cameras OWNER TO odoo;

--
-- Name: cameras_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.cameras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cameras_id_seq OWNER TO odoo;

--
-- Name: cameras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.cameras_id_seq OWNED BY public.cameras.id;


--
-- Name: grabaciones; Type: TABLE; Schema: public; Owner: odoo
--

CREATE TABLE public.grabaciones (
    id integer NOT NULL,
    camera_id integer,
    fecha_inicio timestamp without time zone NOT NULL,
    fecha_fin timestamp without time zone,
    tamano_mb integer,
    archivo character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.grabaciones OWNER TO odoo;

--
-- Name: grabaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: odoo
--

CREATE SEQUENCE public.grabaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grabaciones_id_seq OWNER TO odoo;

--
-- Name: grabaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: odoo
--

ALTER SEQUENCE public.grabaciones_id_seq OWNED BY public.grabaciones.id;


--
-- Name: cameras id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.cameras ALTER COLUMN id SET DEFAULT nextval('public.cameras_id_seq'::regclass);


--
-- Name: grabaciones id; Type: DEFAULT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.grabaciones ALTER COLUMN id SET DEFAULT nextval('public.grabaciones_id_seq'::regclass);


--
-- Data for Name: cameras; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.cameras (id, nombre, ubicacion, ip_address, puerto, usuario, contrasena, modelo, firmware, created_at) FROM stdin;
1	Camara Bodega Norte	Bodega principal, estantería A1	192.168.1.101	554	admin	cctv_pass_2026_bodega	DS-2CD2T47G2-L	V5.7.0	2026-07-18 16:47:19.872611
2	Camara Bodega Sur	Bodega principal, estantería C3	192.168.1.102	554	admin	cctv_pass_2026_bodega	DS-2CD2T47G2-L	V5.7.0	2026-07-18 16:47:19.872611
3	Camara Showroom	Showroom principal, entrada	192.168.1.103	554	admin	cctv_pass_2026_showroom	DS-2CD2386G2-I	V5.8.1	2026-07-18 16:47:19.872611
4	Camara Caja	Showroom, punto de caja	192.168.1.104	554	admin	cctv_pass_2026_showroom	DS-2CD2386G2-I	V5.8.1	2026-07-18 16:47:19.872611
5	Camara Data Center	Cuarto servidores, rack principal	192.168.1.105	554	admin	cctv_pass_2026_dc	DS-2CD2347G2-LU	V5.7.2	2026-07-18 16:47:19.872611
6	Camara Recepcion	Oficinas administrativas, recepción	192.168.1.106	554	admin	cctv_pass_2026_oficinas	DS-2CD2T47G2-L	V5.7.0	2026-07-18 16:47:19.872611
7	Camara Gerencia	Oficina gerencia general	192.168.1.107	554	admin	cctv_pass_2026_oficinas	DS-2CD2347G2-LU	V5.7.2	2026-07-18 16:47:19.872611
8	Camara Estacionamiento	Estacionamiento exterior	192.168.1.108	554	admin	cctv_pass_2026_exterior	DS-2CD2T47G2-L	V5.7.0	2026-07-18 16:47:19.872611
9	Camara Puerta Trasera	Salida emergencia bodega	192.168.1.109	554	admin	cctv_pass_2026_bodega	DS-2CD2T47G2-L	V5.7.0	2026-07-18 16:47:19.872611
10	Camara Sucursal GYE	Sucursal Guayaquil, bodega	192.168.5.101	554	admin	cctv_pass_2026_gye	DS-2CD2T47G2-L	V5.7.1	2026-07-18 16:47:19.872611
\.


--
-- Data for Name: grabaciones; Type: TABLE DATA; Schema: public; Owner: odoo
--

COPY public.grabaciones (id, camera_id, fecha_inicio, fecha_fin, tamano_mb, archivo, created_at) FROM stdin;
1	1	2026-07-17 08:00:00	2026-07-17 09:00:00	2048	/mnt/storage/nvr/01/20260717-0800.mp4	2026-07-18 16:47:19.886775
2	1	2026-07-17 09:00:00	2026-07-17 10:00:00	1980	/mnt/storage/nvr/01/20260717-0900.mp4	2026-07-18 16:47:19.886775
3	2	2026-07-17 08:00:00	2026-07-17 09:00:00	1850	/mnt/storage/nvr/02/20260717-0800.mp4	2026-07-18 16:47:19.886775
4	3	2026-07-17 08:00:00	2026-07-17 09:00:00	2100	/mnt/storage/nvr/03/20260717-0800.mp4	2026-07-18 16:47:19.886775
\.


--
-- Name: cameras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.cameras_id_seq', 10, true);


--
-- Name: grabaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: odoo
--

SELECT pg_catalog.setval('public.grabaciones_id_seq', 4, true);


--
-- Name: cameras cameras_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_pkey PRIMARY KEY (id);


--
-- Name: grabaciones grabaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.grabaciones
    ADD CONSTRAINT grabaciones_pkey PRIMARY KEY (id);


--
-- Name: grabaciones grabaciones_camera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: odoo
--

ALTER TABLE ONLY public.grabaciones
    ADD CONSTRAINT grabaciones_camera_id_fkey FOREIGN KEY (camera_id) REFERENCES public.cameras(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: odoo
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 0sHMseLwzs6EoCxtjgSNS76AGHs6tCNVPVys4VInKNPbo1jmN203be7ND8ZCmvr

